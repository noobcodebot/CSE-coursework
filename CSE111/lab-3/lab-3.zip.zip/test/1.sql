-- account balance, phone number, and address Customer#000000020
select c_acctbal, c_phone, c_address from customer
where c_name = "Customer#000000020";