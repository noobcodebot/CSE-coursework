-- What are the smallest and largest account balances of a supplier
select min(s_acctbal), max(s_acctbal) from supplier;