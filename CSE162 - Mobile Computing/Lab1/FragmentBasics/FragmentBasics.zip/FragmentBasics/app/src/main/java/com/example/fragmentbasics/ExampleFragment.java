package com.example.fragmentbasics;

import androidx.fragment.app.Fragment;

public class ExampleFragment extends Fragment {
    public ExampleFragment() {
        super(R.layout.example_fragment);
    }
}
